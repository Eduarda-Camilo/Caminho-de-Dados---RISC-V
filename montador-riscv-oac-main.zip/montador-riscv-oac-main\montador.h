#ifndef MONTADOR_H
#define MONTADOR_H

// Função principal que monta o arquivo de entrada e gera a saída
int montar_arquivo(const char *arquivo_entrada, const char *arquivo_saida);

#endif // MONTADOR_H